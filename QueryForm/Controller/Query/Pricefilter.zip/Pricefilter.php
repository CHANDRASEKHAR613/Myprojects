<?php

namespace Codilar\QueryForm\Controller\Query;

use Magento\Framework\App\Action\Action;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Framework\Setup\Exception;
use \Psr\Log\LoggerInterface;
use Magento\Catalog\Model\Product\Attribute\Repository as AttributeRepository;
use Magento\Framework\App\Action\Context;

class PriceFilter extends Action
{
    /**
     * @var AttributeRepository
     */
    protected $attributeRepository;
    /**
     * @var ProductRepositoryInterface
     */
    protected $productRepository;

    /**
     * @var Product
     */
    protected $product;



    public function __construct(
        AttributeRepository        $attributeRepository,
        ProductRepositoryInterface $productRepository,
        LoggerInterface            $loggerResponse,
        CollectionFactory          $productCollectionFactory,
        Product                    $product,
        Action                     $action,
        Context                    $context
    )
    {
        $this->attributeRepository = $attributeRepository;
        $this->_productCollectionFactory = $productCollectionFactory;
        $this->action = $action;
        $this->logger = $loggerResponse;
        $this->productRepository = $productRepository;
        $this->product = $product;
        parent::__construct($context);
    }

    public function execute()
    {
        try {
            $collection = $this->_productCollectionFactory->create()
                ->addAttributeToSelect('*');
//         $collection->addAttributeToFilter('sku','APP-0028-000010-431');
            foreach ($collection as $products) {
                $products->getCustomAttribute('price_filter');
                $PriceFilterValue = $products->getPriceFilter();
                $name = $products->getName();
                $priceFitler = $products->getPriceFitler();
                $price = $products->getSpecialPrice();
                if (empty($price)) {
                    $price = $products->getFinalPrice();
                }
                $arr = $this->getAttributeValues();
                $index1 = 1;
                $index0 = 0;
                while (isset($arr[$index1][$index0])) {
                    $exploded = (explode("-", $arr[$index1][$index0]));
                    //print_r($exploded)."exploded";
                    if ($price >= $exploded[0] && $price <= $exploded[1]) {
                        $finalvalue = $arr[$index1][1];
                        break;
                    }
                    $index1++;
                }//end while
                /*echo "<pre>";
                print_r($PriceFilterValue . "--current value--->");*/
                if (!($PriceFilterValue == $finalvalue)) {
                   // echo $finalvalue . '-----Updated Value  ----->' . $name;
                    $products->setCustomAttribute('price_filter', $finalvalue);
                    $products->save();
                }//end if
            }//end foreach
        } catch (Exception $e) {
            $this->loggerResponse->critical($e->getMessage());
        }//end try
    }


    public function getAttributeValues()
    {
        $item = [];
        $attribute = $this->attributeRepository->get('price_filter')->getOptions();
        foreach ($attribute as $value) {
            $item[] = [$value->getLabel(), $value->getValue()];
        }
        return $item;
    }
}
